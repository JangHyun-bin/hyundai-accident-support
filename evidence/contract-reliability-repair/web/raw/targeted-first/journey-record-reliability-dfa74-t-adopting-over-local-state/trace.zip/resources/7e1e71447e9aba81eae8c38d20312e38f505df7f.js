import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];const lazy = __vite__cjsImport0_react["lazy"]; const Suspense = __vite__cjsImport0_react["Suspense"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=ed44db3c";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=ed44db3c";
import App from "/src/App.tsx";
import { ToolsStudy } from "/src/ToolsStudy.tsx";
import { EmergencyStudy } from "/src/emergency/EmergencyStudy.tsx";
import { EmergencyCatalog } from "/src/emergency/EmergencyCatalog.tsx";
import { JourneyCatalog } from "/src/journey/JourneyCatalog.tsx";
import { JourneyStudy } from "/src/journey/JourneyStudy.tsx";
import { ResponseConceptStudy } from "/src/journey/ResponseConceptStudy.tsx";
import { ResponseNumeralStudy } from "/src/journey/ResponseNumeralStudy.tsx";
import { ResponseSurfaceStudy } from "/src/journey/ResponseSurfaceStudy.tsx";
import { ResponseSplitStudy } from "/src/journey/ResponseSplitStudy.tsx";
import { SurfaceThemeProvider } from "/src/design-system/SurfaceTheme.tsx";
import { DesignSystemCatalog } from "/src/design-system/DesignSystemCatalog.tsx";
import "/src/styles.css";
var _jsxFileName = "$REPO/prototype/web/src/main.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ed44db3c";
const FlowStudy = import.meta.env.DEV ? lazy(() => import("/src/design-system/FlowStudy.tsx").then((module) => ({ default: module.FlowStudy }))) : null;
const InteractionStudy = import.meta.env.DEV ? lazy(() => import("/src/design-system/InteractionStudy.tsx").then((module) => ({ default: module.InteractionStudy }))) : null;
const VehicleContourStudy = import.meta.env.DEV ? lazy(() => import("/src/design-system/VehicleContourStudy.tsx").then((module) => ({ default: module.VehicleContourStudy }))) : null;
const SurroundingsStudy = import.meta.env.DEV ? lazy(() => import("/src/design-system/SurroundingsStudy.tsx").then((module) => ({ default: module.SurroundingsStudy }))) : null;
const study = new URLSearchParams(location.search).get("study");
const focus = new URLSearchParams(location.search).get("focus");
const requestedView = new URLSearchParams(location.search).get("view");
const surroundingsView = requestedView === "front" || requestedView === "current" || requestedView === "replay" ? requestedView : "vehicle";
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(SurfaceThemeProvider, { children: study === "flow" && FlowStudy ? /* @__PURE__ */ _jsxDEV(Suspense, {
	fallback: /* @__PURE__ */ _jsxDEV("p", { children: "Study 불러오는 중" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 128
	}, this),
	children: /* @__PURE__ */ _jsxDEV(FlowStudy, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 149
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 108
}, this) : study === "surroundings" && SurroundingsStudy ? /* @__PURE__ */ _jsxDEV(Suspense, {
	fallback: /* @__PURE__ */ _jsxDEV("p", { children: "Study 불러오는 중" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 243
	}, this),
	children: /* @__PURE__ */ _jsxDEV(SurroundingsStudy, { initialView: surroundingsView }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 264
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 223
}, this) : study === "vehicle" && VehicleContourStudy ? /* @__PURE__ */ _jsxDEV(Suspense, {
	fallback: /* @__PURE__ */ _jsxDEV("p", { children: "Study 불러오는 중" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 394
	}, this),
	children: /* @__PURE__ */ _jsxDEV(VehicleContourStudy, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 415
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 374
}, this) : study === "interaction" && InteractionStudy ? /* @__PURE__ */ _jsxDEV(Suspense, {
	fallback: /* @__PURE__ */ _jsxDEV("p", { children: "Study 불러오는 중" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 517
	}, this),
	children: /* @__PURE__ */ _jsxDEV(InteractionStudy, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 538
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 497
}, this) : study === "design-system" ? /* @__PURE__ */ _jsxDEV(DesignSystemCatalog, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 599
}, this) : study === "response-alts" && import.meta.env.DEV ? focus === "split" ? /* @__PURE__ */ _jsxDEV(ResponseSplitStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 696
}, this) : focus === "surface" ? /* @__PURE__ */ _jsxDEV(ResponseSurfaceStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 743
}, this) : focus === "numeral" ? /* @__PURE__ */ _jsxDEV(ResponseNumeralStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 792
}, this) : /* @__PURE__ */ _jsxDEV(ResponseConceptStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 819
}, this) : study === "journey" ? /* @__PURE__ */ _jsxDEV(JourneyStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 868
}, this) : study === "journey-catalog" ? /* @__PURE__ */ _jsxDEV(JourneyCatalog, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 917
}, this) : study === "emergency-catalog" ? /* @__PURE__ */ _jsxDEV(EmergencyCatalog, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 970
}, this) : study === "emergency" ? /* @__PURE__ */ _jsxDEV(EmergencyStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 1017
}, this) : study === "tools" ? /* @__PURE__ */ _jsxDEV(ToolsStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 1058
}, this) : study === "legacy" ? /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 1096
}, this) : /* @__PURE__ */ _jsxDEV(JourneyStudy, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 1106
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 53
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUSxNQUFLLGdCQUFlO0FBQzVCLFNBQVMsa0JBQWtCO0FBQzNCLE9BQU8sU0FBUztBQUNoQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLDJCQUEyQjtBQUNwQyxPQUFPOzs7QUFHUCxNQUFNLFlBQVUsWUFBWSxJQUFJLE1BQUksV0FBUyxPQUFPLDRCQUE0QixDQUFDLE1BQUssWUFBUyxFQUFDLFNBQVEsT0FBTyxVQUFTLEVBQUUsQ0FBQyxJQUFFO0FBRTdILE1BQU0sbUJBQWlCLFlBQVksSUFBSSxNQUFJLFdBQVMsT0FBTyxtQ0FBbUMsQ0FBQyxNQUFLLFlBQVMsRUFBQyxTQUFRLE9BQU8saUJBQWdCLEVBQUUsQ0FBQyxJQUFFO0FBQ2xKLE1BQU0sc0JBQW9CLFlBQVksSUFBSSxNQUFJLFdBQVMsT0FBTyxzQ0FBc0MsQ0FBQyxNQUFLLFlBQVMsRUFBQyxTQUFRLE9BQU8sb0JBQW1CLEVBQUUsQ0FBQyxJQUFFO0FBRTNKLE1BQU0sb0JBQWtCLFlBQVksSUFBSSxNQUFJLFdBQVMsT0FBTyxvQ0FBb0MsQ0FBQyxNQUFLLFlBQVMsRUFBQyxTQUFRLE9BQU8sa0JBQWlCLEVBQUUsQ0FBQyxJQUFFO0FBRXJKLE1BQU0sUUFBUSxJQUFJLGdCQUFnQixTQUFTLE1BQU0sQ0FBQyxDQUFDLElBQUksT0FBTztBQUM5RCxNQUFNLFFBQVEsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLENBQUMsQ0FBQyxJQUFJLE9BQU87QUFDOUQsTUFBTSxnQkFBZ0IsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLENBQUMsQ0FBQyxJQUFJLE1BQU07QUFDckUsTUFBTSxtQkFBb0Msa0JBQWdCLFdBQVMsa0JBQWdCLGFBQVcsa0JBQWdCLFdBQVMsZ0JBQWM7QUFDckksV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFFLENBQUMsQ0FBQyxPQUFPLHdCQUFDLHNCQUFELFlBQXVCLFVBQVUsVUFBVSxZQUFZLHdCQUFDLFVBQUQ7Q0FBVSxVQUFVLHdCQUFDLEtBQUQsWUFBRyxlQUFlOzs7OztXQUFHLHdCQUFDLFdBQUQsQ0FBVzs7Ozs7QUFBVzs7OztXQUFJLFVBQVUsa0JBQWtCLG9CQUFvQix3QkFBQyxVQUFEO0NBQVUsVUFBVSx3QkFBQyxLQUFELFlBQUcsZUFBZTs7Ozs7V0FBRyx3QkFBQyxtQkFBRCxFQUFtQixhQUFhLGlCQUFrQjs7Ozs7QUFBVzs7OztXQUFJLFVBQVUsYUFBYSxzQkFBc0Isd0JBQUMsVUFBRDtDQUFVLFVBQVUsd0JBQUMsS0FBRCxZQUFHLGVBQWU7Ozs7O1dBQUcsd0JBQUMscUJBQUQsQ0FBcUI7Ozs7O0FBQVc7Ozs7V0FBSSxVQUFVLGlCQUFpQixtQkFBbUIsd0JBQUMsVUFBRDtDQUFVLFVBQVUsd0JBQUMsS0FBRCxZQUFHLGVBQWU7Ozs7O1dBQUcsd0JBQUMsa0JBQUQsQ0FBa0I7Ozs7O0FBQVc7Ozs7V0FBSSxVQUFVLGtCQUFrQix3QkFBQyxxQkFBRCxDQUFzQjs7OztXQUFJLFVBQVUsbUJBQW1CLFlBQVksSUFBSSxNQUFNLFVBQVUsVUFBVSx3QkFBQyxvQkFBRCxDQUFxQjs7OztXQUFJLFVBQVUsWUFBWSx3QkFBQyxzQkFBRCxDQUF1Qjs7OztXQUFJLFVBQVUsWUFBWSx3QkFBQyxzQkFBRCxDQUF1Qjs7OztXQUFJLHdCQUFDLHNCQUFELENBQXVCOzs7O1dBQUksVUFBVSxZQUFZLHdCQUFDLGNBQUQsQ0FBZTs7OztXQUFJLFVBQVUsb0JBQW9CLHdCQUFDLGdCQUFELENBQWlCOzs7O1dBQUksVUFBVSxzQkFBc0Isd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7V0FBSSxVQUFVLGNBQWMsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7V0FBSSxVQUFVLFVBQVUsd0JBQUMsWUFBRCxDQUFhOzs7O1dBQUksVUFBVSxXQUFXLHdCQUFDLEtBQUQsQ0FBTTs7OztXQUFJLHdCQUFDLGNBQUQsQ0FBZTs7OztTQUF3Qjs7OztRQUFDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7bGF6eSxTdXNwZW5zZX0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAnXG5pbXBvcnQgeyBUb29sc1N0dWR5IH0gZnJvbSAnLi9Ub29sc1N0dWR5J1xuaW1wb3J0IHsgRW1lcmdlbmN5U3R1ZHkgfSBmcm9tICcuL2VtZXJnZW5jeS9FbWVyZ2VuY3lTdHVkeSdcbmltcG9ydCB7IEVtZXJnZW5jeUNhdGFsb2cgfSBmcm9tICcuL2VtZXJnZW5jeS9FbWVyZ2VuY3lDYXRhbG9nJ1xuaW1wb3J0IHsgSm91cm5leUNhdGFsb2cgfSBmcm9tICcuL2pvdXJuZXkvSm91cm5leUNhdGFsb2cnXG5pbXBvcnQgeyBKb3VybmV5U3R1ZHkgfSBmcm9tICcuL2pvdXJuZXkvSm91cm5leVN0dWR5J1xuaW1wb3J0IHsgUmVzcG9uc2VDb25jZXB0U3R1ZHkgfSBmcm9tICcuL2pvdXJuZXkvUmVzcG9uc2VDb25jZXB0U3R1ZHknXG5pbXBvcnQgeyBSZXNwb25zZU51bWVyYWxTdHVkeSB9IGZyb20gJy4vam91cm5leS9SZXNwb25zZU51bWVyYWxTdHVkeSdcbmltcG9ydCB7IFJlc3BvbnNlU3VyZmFjZVN0dWR5IH0gZnJvbSAnLi9qb3VybmV5L1Jlc3BvbnNlU3VyZmFjZVN0dWR5J1xuaW1wb3J0IHsgUmVzcG9uc2VTcGxpdFN0dWR5IH0gZnJvbSAnLi9qb3VybmV5L1Jlc3BvbnNlU3BsaXRTdHVkeSdcbmltcG9ydCB7IFN1cmZhY2VUaGVtZVByb3ZpZGVyIH0gZnJvbSAnLi9kZXNpZ24tc3lzdGVtL1N1cmZhY2VUaGVtZSdcbmltcG9ydCB7IERlc2lnblN5c3RlbUNhdGFsb2cgfSBmcm9tICcuL2Rlc2lnbi1zeXN0ZW0vRGVzaWduU3lzdGVtQ2F0YWxvZydcbmltcG9ydCAnLi9zdHlsZXMuY3NzJ1xuaW1wb3J0IHR5cGUge1N1cnJvdW5kaW5nc1ZpZXd9IGZyb20gJy4vZGVzaWduLXN5c3RlbS9TdXJyb3VuZGluZ3NTdHVkeSdcblxuY29uc3QgRmxvd1N0dWR5PWltcG9ydC5tZXRhLmVudi5ERVY/bGF6eSgoKT0+aW1wb3J0KCcuL2Rlc2lnbi1zeXN0ZW0vRmxvd1N0dWR5JykudGhlbihtb2R1bGU9Pih7ZGVmYXVsdDptb2R1bGUuRmxvd1N0dWR5fSkpKTpudWxsXG5cbmNvbnN0IEludGVyYWN0aW9uU3R1ZHk9aW1wb3J0Lm1ldGEuZW52LkRFVj9sYXp5KCgpPT5pbXBvcnQoJy4vZGVzaWduLXN5c3RlbS9JbnRlcmFjdGlvblN0dWR5JykudGhlbihtb2R1bGU9Pih7ZGVmYXVsdDptb2R1bGUuSW50ZXJhY3Rpb25TdHVkeX0pKSk6bnVsbFxuY29uc3QgVmVoaWNsZUNvbnRvdXJTdHVkeT1pbXBvcnQubWV0YS5lbnYuREVWP2xhenkoKCk9PmltcG9ydCgnLi9kZXNpZ24tc3lzdGVtL1ZlaGljbGVDb250b3VyU3R1ZHknKS50aGVuKG1vZHVsZT0+KHtkZWZhdWx0Om1vZHVsZS5WZWhpY2xlQ29udG91clN0dWR5fSkpKTpudWxsXG5cbmNvbnN0IFN1cnJvdW5kaW5nc1N0dWR5PWltcG9ydC5tZXRhLmVudi5ERVY/bGF6eSgoKT0+aW1wb3J0KCcuL2Rlc2lnbi1zeXN0ZW0vU3Vycm91bmRpbmdzU3R1ZHknKS50aGVuKG1vZHVsZT0+KHtkZWZhdWx0Om1vZHVsZS5TdXJyb3VuZGluZ3NTdHVkeX0pKSk6bnVsbFxuXG5jb25zdCBzdHVkeSA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKS5nZXQoJ3N0dWR5JylcbmNvbnN0IGZvY3VzID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpLmdldCgnZm9jdXMnKVxuY29uc3QgcmVxdWVzdGVkVmlldyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKS5nZXQoJ3ZpZXcnKVxuY29uc3Qgc3Vycm91bmRpbmdzVmlldzpTdXJyb3VuZGluZ3NWaWV3ID0gcmVxdWVzdGVkVmlldz09PSdmcm9udCd8fHJlcXVlc3RlZFZpZXc9PT0nY3VycmVudCd8fHJlcXVlc3RlZFZpZXc9PT0ncmVwbGF5Jz9yZXF1ZXN0ZWRWaWV3Oid2ZWhpY2xlJ1xuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpISkucmVuZGVyKDxTdXJmYWNlVGhlbWVQcm92aWRlcj57c3R1ZHkgPT09ICdmbG93JyAmJiBGbG93U3R1ZHkgPyA8U3VzcGVuc2UgZmFsbGJhY2s9ezxwPlN0dWR5IOu2iOufrOyYpOuKlCDspJE8L3A+fT48Rmxvd1N0dWR5Lz48L1N1c3BlbnNlPiA6IHN0dWR5ID09PSAnc3Vycm91bmRpbmdzJyAmJiBTdXJyb3VuZGluZ3NTdHVkeSA/IDxTdXNwZW5zZSBmYWxsYmFjaz17PHA+U3R1ZHkg67aI65+s7Jik64qUIOykkTwvcD59PjxTdXJyb3VuZGluZ3NTdHVkeSBpbml0aWFsVmlldz17c3Vycm91bmRpbmdzVmlld30vPjwvU3VzcGVuc2U+IDogc3R1ZHkgPT09ICd2ZWhpY2xlJyAmJiBWZWhpY2xlQ29udG91clN0dWR5ID8gPFN1c3BlbnNlIGZhbGxiYWNrPXs8cD5TdHVkeSDrtojrn6zsmKTripQg7KSRPC9wPn0+PFZlaGljbGVDb250b3VyU3R1ZHkvPjwvU3VzcGVuc2U+IDogc3R1ZHkgPT09ICdpbnRlcmFjdGlvbicgJiYgSW50ZXJhY3Rpb25TdHVkeSA/IDxTdXNwZW5zZSBmYWxsYmFjaz17PHA+U3R1ZHkg67aI65+s7Jik64qUIOykkTwvcD59PjxJbnRlcmFjdGlvblN0dWR5Lz48L1N1c3BlbnNlPiA6IHN0dWR5ID09PSAnZGVzaWduLXN5c3RlbScgPyA8RGVzaWduU3lzdGVtQ2F0YWxvZyAvPiA6IHN0dWR5ID09PSAncmVzcG9uc2UtYWx0cycgJiYgaW1wb3J0Lm1ldGEuZW52LkRFViA/IGZvY3VzID09PSAnc3BsaXQnID8gPFJlc3BvbnNlU3BsaXRTdHVkeSAvPiA6IGZvY3VzID09PSAnc3VyZmFjZScgPyA8UmVzcG9uc2VTdXJmYWNlU3R1ZHkgLz4gOiBmb2N1cyA9PT0gJ251bWVyYWwnID8gPFJlc3BvbnNlTnVtZXJhbFN0dWR5IC8+IDogPFJlc3BvbnNlQ29uY2VwdFN0dWR5IC8+IDogc3R1ZHkgPT09ICdqb3VybmV5JyA/IDxKb3VybmV5U3R1ZHkgLz4gOiBzdHVkeSA9PT0gJ2pvdXJuZXktY2F0YWxvZycgPyA8Sm91cm5leUNhdGFsb2cgLz4gOiBzdHVkeSA9PT0gJ2VtZXJnZW5jeS1jYXRhbG9nJyA/IDxFbWVyZ2VuY3lDYXRhbG9nIC8+IDogc3R1ZHkgPT09ICdlbWVyZ2VuY3knID8gPEVtZXJnZW5jeVN0dWR5IC8+IDogc3R1ZHkgPT09ICd0b29scycgPyA8VG9vbHNTdHVkeSAvPiA6IHN0dWR5ID09PSAnbGVnYWN5JyA/IDxBcHAgLz4gOiA8Sm91cm5leVN0dWR5IC8+fTwvU3VyZmFjZVRoZW1lUHJvdmlkZXI+KVxuIl19